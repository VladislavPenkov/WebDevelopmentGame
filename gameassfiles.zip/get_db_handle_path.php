<?php
    define("GET_DB_HANDLE_PATH", "/aber/vmp1/PHP");

?>
